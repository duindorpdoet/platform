// One local QR02 acceptance body. Real Chromium permissions and media API,
// a Chromium virtual camera, no fake-ui flag and no JavaScript media stub.
import {join} from 'node:path';

export async function runCameraDenied(ctx) {
 const {base,a,snapshot,report,directory,assert,checked,qr,createPage}=ctx;
 assert(base==='http://127.0.0.1:3137'&&typeof ctx.assertScope==='function','QR02_LOCAL_VERIFIED_SCOPE_REQUIRED');
 await ctx.assertScope();
 const before=await snapshot(a);
 assert(before.actor.id===a.id&&before.event.id===ctx.eventId&&before.event.slug===ctx.slug&&before.event.test&&before.event.environment==='staging','QR02_EFFECTIVE_ACTOR_EDITION_REQUIRED');
 assert(before.registration?.status==='active'&&before.registration.paymentStatus==='paid'&&before.journey?.state==='ready'&&!before.current,'QR02_FRESH_PAID_READY_FAMILY_REQUIRED');
 await a.context.grantPermissions([],{origin:base});
 const page=await createPage(a,'/nachtpas');let errors=0;const failedScripts=[];
 page.on('pageerror',()=>errors++);page.on('response',response=>{if(response.request().resourceType()==='script'&&response.status()>=400)failedScripts.push(response.status())});
 try{
  const permission=await page.evaluate(async()=>{
   const state=(await navigator.permissions.query({name:'camera'})).state;
   const nativeMedia=navigator.mediaDevices.getUserMedia.toString().includes('[native code]');
   const nativePermission=navigator.permissions.query.toString().includes('[native code]');
   try{const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'},audio:false});stream.getTracks().forEach(track=>track.stop());return{state,nativeMedia,nativePermission,rejection:null}}
   catch(error){return{state,nativeMedia,nativePermission,rejection:error.name}}
  });
  assert(permission.state==='denied'&&permission.nativeMedia&&permission.nativePermission&&permission.rejection==='NotAllowedError','QR02_NATIVE_DENIED_NOT_ALLOWED_REQUIRED');
  report.cameraDenied={permission:permission.state,nativeMediaAPI:permission.nativeMedia,nativePermissionAPI:permission.nativePermission,nativeMediaRejection:permission.rejection,browser:'full Chromium headless channel',virtualDevice:'Chromium --use-fake-device-for-media-stream',fakeUI:false,javaScriptMediaMock:false,physicalCameraVerified:false};
  const start=page.getByRole('button',{name:'Scan de start-QR',exact:true});await start.focus();await page.keyboard.press('Enter');
  const dialog=page.locator('#fn-scan-dialog');await dialog.waitFor();
  await dialog.getByRole('button',{name:'Open camera',exact:true}).click();
  const message='De camera is niet beschikbaar of toestemming is geweigerd. Gebruik de code op het bord.';
  await dialog.getByText(message,{exact:true}).waitFor();
  assert(await dialog.getByRole('button',{name:'Open camera',exact:true}).isVisible()&&await dialog.getByLabel('Of voer de code van het bord in',{exact:true}).isEditable(),'QR02_MANUAL_FALLBACK_NOT_AVAILABLE');
  const afterDenial=await snapshot(a);
  assert(!afterDenial.current&&afterDenial.journey.state==='ready'&&afterDenial.journey.version===before.journey.version&&afterDenial.progress.awards.length===before.progress.awards.length&&afterDenial.progress.visits.length===before.progress.visits.length,'QR02_PERMISSION_ERROR_MUTATED_AUTHORITY');
  for(const width of[390,1440]){
   await page.setViewportSize({width,height:width===390?844:1000});await page.evaluate(()=>document.activeElement?.blur());
   assert(!await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),'QR02_FALLBACK_DOCUMENT_OVERFLOW');
   const file=`camera-permission-denied-fallback-${width}.png`;await page.screenshot({path:join(directory,file),fullPage:true,mask:[dialog.locator('input')]});report.screenshots.push(file);
  }
  checked('QR02 real Chromium camera permission denied and native NotAllowedError expose readable editable manual fallback without route or reward mutation',{nativeCameraPermission:'denied',nativeMediaError:'NotAllowedError',virtualChromiumDevice:true,javaScriptMediaMock:false});
  const token=await qr();
  const input=dialog.getByLabel('Of voer de code van het bord in',{exact:true});await input.focus();await input.fill(token);
  const waiting=page.waitForResponse(response=>new URL(response.url()).origin===base&&new URL(response.url()).pathname==='/api/frightnight/command'&&response.request().method()==='POST'&&response.request().postDataJSON()?.operation==='journey.start');
  await dialog.getByRole('button',{name:'Controleer code',exact:true}).click();const response=await waiting;
  assert(response.ok(),'QR02_MANUAL_START_NOT_CONFIRMED');
  await dialog.waitFor({state:'hidden'});
  const after=await snapshot(a),body=(await response.json()).data;
  assert(body.ok===true&&body.snapshot.event.id===ctx.eventId&&after.current?.id&&after.journey.state==='walking'&&after.journey.version>before.journey.version&&body.snapshot.current?.id===after.current.id,'QR02_SERVER_DESTINATION_NOT_RELEASED');
  assert(after.progress.awards.length===before.progress.awards.length&&after.progress.visits.length===before.progress.visits.length,'QR02_START_FALSE_VISIT_OR_REWARD');
  assert((await page.evaluate(async()=>(await navigator.permissions.query({name:'camera'})).state))==='denied','QR02_PERMISSION_CHANGED_TO_ACCEPT_MANUAL');
  assert(errors===0&&failedScripts.length===0,'QR02_BROWSER_SCRIPT_FAILURE');
  for(const width of[390,1440]){await page.setViewportSize({width,height:width===390?844:1000});await page.evaluate(()=>{document.activeElement?.blur();window.scrollTo(0,0)});const file=`camera-denied-manual-server-route-${width}.png`;await page.screenshot({path:join(directory,file),fullPage:true});report.screenshots.push(file)}
  checked('QR02 same denied-camera dialog accepts actual start-board code and server releases exactly one current destination without claiming a visit',{serverConfirmed:true,permissionRemainsDenied:true,physicalCameraVerified:false});
  report.cameraDenied.status='passed';
 }finally{await page.close().catch(()=>{})}
}
