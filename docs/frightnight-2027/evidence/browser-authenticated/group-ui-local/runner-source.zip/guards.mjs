export const TARGET = Object.freeze({origin:'https://staging-halloween.duindorpdoet.nl',projectRef:'nocteiuvohesvqbowchw',slug:'frightnight-2027-test'});
const fail=code=>{throw new Error(code)};
export function guardHosted(env,head){
 if(!/^[a-f0-9]{40}$/.test(head??'')||env.GITHUB_SHA!==head||env.FRIGHTNIGHT_VERIFIED_RELEASE_SHA!==head)fail('SUPPLEMENT_EXACT_SOURCE_AND_VERIFIED_SHA_REQUIRED');
 if(env.APP_ENVIRONMENT!=='staging'||env.APP_URL!==TARGET.origin||env.EVENT_SLUG!==TARGET.slug||env.FRIGHTNIGHT_PROJECT_REF!==TARGET.projectRef||env.SUPABASE_PROJECT_REF!==TARGET.projectRef||env.NEXT_PUBLIC_SUPABASE_URL!==`https://${TARGET.projectRef}.supabase.co`||env.FRIGHTNIGHT_ENABLED!=='true')fail('SUPPLEMENT_EXACT_STAGING_BINDING_REQUIRED');
 if(env.FRIGHTNIGHT_PAYMENT_PROVIDER!=='contract'||env.FRIGHTNIGHT_MAIL_MODE!=='sink'||env.FRIGHTNIGHT_HARDWARE_ENABLED!=='false')fail('SUPPLEMENT_CONTRACT_SINK_NO_HARDWARE_REQUIRED');
 if(env.FRIGHTNIGHT_SUPPLEMENT_APPROVAL!==`${TARGET.projectRef}:staging:duindorphalloweenstg:${head}:supplemental`)fail('SUPPLEMENT_SEPARATE_EXPLICIT_EXECUTION_APPROVAL_REQUIRED');
 for(const key of ['NEXT_PUBLIC_SUPABASE_ANON_KEY','SUPABASE_SERVICE_ROLE_KEY','SUPABASE_ACCESS_TOKEN'])if(!env[key])fail('SUPPLEMENT_REQUIRED_SERVER_CONFIGURATION_MISSING');
 return TARGET;
}
export function guardLocal(env,origin='http://127.0.0.1:3137'){
 if(origin!=='http://127.0.0.1:3137'||!/^http:\/\/127\.0\.0\.1:[0-9]+\/?$/.test(env.NEXT_PUBLIC_SUPABASE_URL??''))fail('SUPPLEMENT_LOCAL_GATEWAY_ONLY');
 if(env.FRIGHTNIGHT_PAYMENT_PROVIDER!=='contract'||env.FRIGHTNIGHT_MAIL_MODE!=='sink'||env.FRIGHTNIGHT_HARDWARE_ENABLED!=='false')fail('SUPPLEMENT_CONTRACT_SINK_NO_HARDWARE_REQUIRED');
 return {...TARGET,origin};
}
export function guardHealth(health,head,hosted){
 if(health?.status!=='ok'||!(hosted?health?.environment==='staging':['test','staging'].includes(health?.environment))||health?.eventSlug!==TARGET.slug||health?.paymentProvider!=='contract'||health?.brand!=='frightnight-2027-v7'||hosted&&health.revision!==head)fail('SUPPLEMENT_EFFECTIVE_HEALTH_BINDING_REQUIRED');
}
export function ownEdition(value,{eventId,slug,runId,actorId}){
 if(value?.event?.id!==eventId||value.event.slug!==slug||value.event.environment!=='staging'||value.event.test!==true||runId&&value.event.runId!==runId||actorId&&value.actor.id!==actorId)fail('SUPPLEMENT_EFFECTIVE_EDITION_OR_ACTOR_MISMATCH');
 return value;
}
export function assertFreshFixture({eventId,slug,run,actors}){
 if(!/^[0-9a-f-]{36}$/.test(eventId)||!slug.startsWith('frightnight-2027-test-acceptance-supplement-')||!slug.endsWith(run)||!/^supp-[a-z0-9-]{8,45}$/.test(run)||!Array.isArray(actors)||actors.length!==3||new Set(actors.map(p=>p.id)).size!==3||actors.some(p=>!p.email.startsWith(`fn-supp-${run}-`)||!p.email.endsWith('@example.invalid')||!/^[0-9a-f-]{36}$/.test(p.id)))fail('SUPPLEMENT_FRESH_OWN_RUN_FIXTURE_REQUIRED');
}
export function guardRetire(person,{baselineIds,capturedIds,run}){
 if(!person?.email?.startsWith(`fn-supp-${run}-`)||!person.email.endsWith('@example.invalid'))fail('SUPPLEMENT_RETIRE_PREFIX_REQUIRED');
 if(baselineIds?.includes(person.id))fail('SUPPLEMENT_PREEXISTING_AUTH_RETIRE_FORBIDDEN');
 if(!baselineIds&&!capturedIds?.has(person.id))fail('SUPPLEMENT_FRESH_AUTH_PROOF_REQUIRED');
 return person;
}
