FrightNight supplemental acceptance — OUTSIDE THE RELEASE TREE

Status: 15 actual local UI checks and six pure guard tests passed.
No hosted execution has been performed. No app, schema, tracked test or workflow changed.

Latest evidence:
 evidence/supp-20261103-4bf3460b/report.json
 SHA/build/app-file binding and cleanup/preservation are in this report.

Cases: INS-01, INS-08, INS-09, QR-03, REG-04, KID-01, KID-02, BAK-02.
The UI body uses genuine local GoTrue, current Next production UI, commands and
PostgreSQL; payments are explicitly the contract adapter, never an external PSP.
The digital beacon family has zero completed quests and actual final scan.

No-network plan:
 node /tmp/frightnight-supplemental-hosted/runner.mjs
Pure no-network guard tests:
 node --test /tmp/frightnight-supplemental-hosted/guards.test.mjs
Explicit local-only repeat (three NEW .invalid Auth actors, one OWN sibling):
 node /tmp/frightnight-supplemental-hosted/runner.mjs --execute-local-qa
Local mode reads the existing QA .env.local privately and rejects a remote gateway.
It must not be repurposed into staging by replacing a URL.

Hosted mode exists but is NOT wired to any credential context:
 --execute-hosted requires exact checked-out/GITHUB/verified SHA, exact staging
 URL/ref/slug, live health reporting contract mode, sink/no-hardware, existing
 staging anon/service/Management configuration, and independent exact-SHA
 FRIGHTNIGHT_SUPPLEMENT_APPROVAL. These credentials are unavailable locally.
Do not retrieve them from CI logs/proc/artifacts or add a workflow route. Root must
agree an existing safe execution context and explicitly release execution first.

Preservation:
 - fresh .invalid actors only; no OTP, mailbox delivery, PSP or push requests;
 - fresh own event UUID/slug/run; no canonical grants or historical households;
 - genuine authenticated commands and private edition entry service grants;
 - exact own test.reset + close; financial ledger/history and households remain;
 - sessions signed out, own new actors retired; zero Auth deletion;
 - all prior editions/canonical/old Auth IDs/legacy outbox rows+content unchanged.
Earlier failed local harness trials are recorded as failures. Two partial own
scopes were separately closed with exact captured/run metadata, no active claim,
archived-or-empty rows and unchanged financial/Auth-ID/outbox hashes:
 evidence/failed-local-recovery.json

feasibility-61.json reviews every partial package ID. It is a proposal catalog,
not 61 implemented tests. Twenty-seven further scoped automation candidates are
listed; physical/provider/runtime/inventory cases remain explicit.

Final cleanup hardening: explicit protected Auth-ID baseline exclusion and
captured-create fallback; exact setup-response discovery; separate best-effort
close after reset failure. Two actual LOCAL failure injections are preserved in
evidence/cleanup-fault-proof.json (expected failed scenarios, safely closed).
Independent frontend review accepted runner5ebff99a and guards451cf2b8; no remote
execution approval is implied.
