// Supplemental presentation/command body only. The orchestrator owns verified
// target/SHA, new synthetic actors, edition/run binding, payment and cleanup.
// No SQL, credentials, Auth creation, outbound delivery or hardware calls.
import { join } from 'node:path';

export async function runGamesBeacon(ctx) {
  const { base, run, slug, eventId, admin, a, b, app, snapshot, browser, contexts, report, directory, assert, checked, qr, createPage } = ctx;
  assert(typeof ctx.assertScope === 'function', 'SUPPLEMENT_GAMES_SCOPE_CALLBACK_REQUIRED');
  await ctx.assertScope();
  assert(/^[a-f0-9-]{36}$/i.test(eventId) && slug.startsWith('frightnight-2027-test-acceptance-') && typeof run === 'string', 'SUPPLEMENT_GAMES_OWN_EDITION_REQUIRED');
  const detail = { startedAt: new Date().toISOString(), edition: slug, eventId, status: 'running', checks: [], screenshots: [], limits: ['Digital browser beacon only; physical/local beacon hardware is not exercised.', 'Two browser contexts are not two physical phones.', 'No OTP, external PSP, outbound mail or push is requested by this module.'] };
  report.gamesBeacon = detail;
  const check = (ok, code) => assert(ok, code);
  const pass = (id, label, values = {}) => { checked(`${id} ${label}`, { module: 'supplemental-games-beacon', ...values }); detail.checks.push({ id, label, ...values }); };
  let pageErrors = 0;
  const pages = [];
  async function state(person) {
    const value = await snapshot(person);
    check(value.event.id === eventId && value.event.slug === slug && value.event.environment === 'staging' && value.event.test && value.actor.id === person.id, 'SUPPLEMENT_GAMES_EFFECTIVE_SCOPE_MISMATCH');
    return value;
  }
  async function page(person) {
    const result = await createPage(person, '/nachtpas'); pages.push(result);
    result.on('pageerror', () => { pageErrors++; });
    await result.locator('.fn-environment-nav').waitFor();
    return result;
  }
  async function clickCommand(pg, operation, action, expected = 200) {
    const waiting = pg.waitForResponse(response => new URL(response.url()).origin === base && new URL(response.url()).pathname === '/api/frightnight/command' && response.request().method() === 'POST' && response.request().postDataJSON()?.operation === operation);
    await action(); const response = await waiting; const body = await response.json();
    check(response.status() === expected, `SUPPLEMENT_GAMES_UI_${operation}_${response.status()}`);
    return { request: response.request().postDataJSON(), body };
  }
  async function shown(locator) { await locator.waitFor({ state: 'visible' }); }
  async function shot(pg, name, width) {
    await pg.setViewportSize({ width, height: width === 390 ? 844 : 1000 });
    await pg.evaluate(() => { document.activeElement?.blur(); window.scrollTo(0, 0); });
    check(!await pg.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1), 'SUPPLEMENT_GAMES_RESPONSIVE_OVERFLOW');
    const file = `${name}-${width}.png`;
    await pg.screenshot({ path: join(directory, file), fullPage: true, mask: [pg.locator('#fn-scan-dialog input'), pg.locator('.fn-invite')] });
    report.screenshots.push(file); detail.screenshots.push(file);
  }
  try {
    const initialA = await state(a), initialB = await state(b);
    check(initialA.registration?.status === 'active' && initialA.registration.paymentStatus === 'paid' && initialB.registration?.status === 'active' && initialB.registration.paymentStatus === 'paid', 'SUPPLEMENT_GAMES_ACTIVE_PAID_REQUIRED');
    check(initialA.journey?.state === 'ready' && initialB.journey?.state === 'ready' && initialA.quests.every(item => !item.completed) && initialB.quests.every(item => !item.completed), 'SUPPLEMENT_GAMES_FRESH_READY_ACTORS_REQUIRED');
    check(admin.id !== a.id && admin.id !== b.id && a.id !== b.id, 'SUPPLEMENT_GAMES_DISTINCT_ACTORS_REQUIRED');
    const pg = await page(a); await pg.getByRole('button', { name: 'Plein', exact: true }).click();
    const questCommands = [];
    for (const [id, answer] of [['riddle-1', 'kroon'], ['riddle-2', 'lichtbaken'], ['riddle-3', 'kraaienbode']]) {
      const quest = initialA.quests.find(item => item.id === id);
      check(!!quest, 'SUPPLEMENT_GAMES_REQUIRED_RIDDLE_MISSING');
      const article = pg.locator('article.fn-quest').filter({ has: pg.getByRole('heading', { name: quest.title, exact: true }) });
      await article.getByLabel('Jouw antwoord', { exact: true }).fill('onjuist');
      const before = (await state(a)).progress.awards.length;
      await clickCommand(pg, 'quest.answer', () => article.getByRole('button', { name: 'Ontdek het antwoord', exact: true }).click(), 409);
      check((await state(a)).progress.awards.length === before, 'SUPPLEMENT_WRONG_RIDDLE_AWARDED');
      await article.getByLabel('Jouw antwoord', { exact: true }).fill(answer);
      questCommands.push((await clickCommand(pg, 'quest.answer', () => article.getByRole('button', { name: 'Ontdek het antwoord', exact: true }).click())).request);
      await shown(article.getByText('Lichtvonk bewaard', { exact: true }));
      pass('KID-01', 'actual riddle UI rejects wrong answer, accepts retry and persists one award', { questId: id });
    }
    const symbols = pg.locator('article.fn-quest').filter({ has: pg.getByRole('heading', { name: 'Het kroongeheim.', exact: true }) });
    await symbols.getByRole('button', { name: 'Ik heb het onthouden', exact: true }).click();
    for (let index = 0; index < 3; index++) await symbols.getByRole('button', { name: 'Maan', exact: true }).click();
    await clickCommand(pg, 'quest.answer', () => symbols.getByRole('button', { name: 'Maan', exact: true }).click(), 409);
    check(!(await state(a)).quests.find(item => item.id === 'game-1').completed, 'SUPPLEMENT_WRONG_SYMBOLS_AWARDED');
    await symbols.getByRole('button', { name: 'Opnieuw bekijken', exact: true }).click();
    await symbols.getByRole('button', { name: 'Ik heb het onthouden', exact: true }).click();
    for (const symbol of ['Kroon', 'Veer', 'Lantaarn']) await symbols.getByRole('button', { name: symbol, exact: true }).click();
    questCommands.push((await clickCommand(pg, 'quest.answer', () => symbols.getByRole('button', { name: 'Maan', exact: true }).click())).request);
    await shown(symbols.getByText('Kroonzegel bewaard', { exact: true }));
    pass('KID-01', 'actual symbols game rejects wrong sequence and accepts corrected four choices');
    const colours = pg.locator('article.fn-quest').filter({ has: pg.getByRole('heading', { name: 'De kleurenlantaarn.', exact: true }) });
    for (const name of ['fire', 'dunes', 'moon']) await colours.locator(`select[name=${name}]`).selectOption('wit');
    await clickCommand(pg, 'quest.answer', () => colours.getByRole('button', { name: 'Ontsteek de lantaarn', exact: true }).click(), 409);
    check(!(await state(a)).quests.find(item => item.id === 'game-2').completed, 'SUPPLEMENT_WRONG_COLOURS_AWARDED');
    await colours.locator('select[name=fire]').selectOption('amber'); await colours.locator('select[name=dunes]').selectOption('groen');
    questCommands.push((await clickCommand(pg, 'quest.answer', () => colours.getByRole('button', { name: 'Ontsteek de lantaarn', exact: true }).click())).request);
    await shown(colours.getByText('Lantaarnzegel bewaard', { exact: true }));
    pass('KID-01', 'actual colours game rejects wrong submission and persists corrected windows');
    const pairs = pg.locator('article.fn-quest').filter({ has: pg.getByRole('heading', { name: 'De ravenverzameling.', exact: true }) });
    const beforePairs = (await state(a)).progress.awards.length;
    await pairs.getByRole('button', { name: 'Kaart 1, omdraaien', exact: true }).click(); await pairs.getByRole('button', { name: 'Kaart 2, omdraaien', exact: true }).click();
    await shown(pairs.getByText('Deze twee horen niet bij elkaar. Onthoud ze en draai ze weer om.', { exact: true }));
    check((await state(a)).progress.awards.length === beforePairs, 'SUPPLEMENT_MISMATCH_PAIR_AWARDED');
    await shot(pg, 'supplement-games-pairs-retry', 390);
    await pairs.getByRole('button', { name: 'Draai weer om', exact: true }).click();
    for (const [first, second] of [[1, 5], [2, 4]]) {
      await pairs.getByRole('button', { name: `Kaart ${first}, omdraaien`, exact: true }).click();
      await pairs.getByRole('button', { name: `Kaart ${second}, omdraaien`, exact: true }).click();
    }
    await pairs.getByRole('button', { name: 'Kaart 3, omdraaien', exact: true }).click();
    questCommands.push((await clickCommand(pg, 'quest.answer', () => pairs.getByRole('button', { name: 'Kaart 6, omdraaien', exact: true }).click())).request);
    await shown(pairs.getByText('Ravenzegel bewaard', { exact: true }));
    pass('KID-01', 'actual pairs game exposes mismatch retry and accepts all three matched pairs');
    const complete = await state(a);
    check(complete.quests.filter(item => item.completed).length === 6 && complete.progress.awards.filter(item => item.key.startsWith('quest:')).length === 6, 'SUPPLEMENT_SIX_UNIQUE_QUEST_AWARDS_REQUIRED');
    await shot(pg, 'supplement-games-six-completed', 390);
    await pg.reload({ waitUntil: 'domcontentloaded' }); await pg.locator('.fn-environment-nav').waitFor(); await pg.getByRole('button', { name: 'Plein', exact: true }).click();
    await shown(pg.getByText('Lichtvonk bewaard', { exact: true }).nth(2));
    check(await pg.getByText('Lichtvonk bewaard', { exact: true }).count() === 3, 'SUPPLEMENT_RIDDLE_REFRESH_LOST_AWARDS');
    await shown(pg.getByText('Ravenzegel bewaard', { exact: true }));
    const second = await browser.newContext({ storageState: await a.context.storageState(), viewport: { width: 1440, height: 1000 }, serviceWorkers: 'block', reducedMotion: 'reduce' }); contexts.push(second);
    await second.route('**/*', route => {
      const url = new URL(route.request().url());
      return /\/auth\/v1\/(otp|magiclink|recover|signup|invite)|\/api\/push\/test|\/api\/mail\//.test(url.pathname) || /(^|\.)mollie\.com$/.test(url.hostname) ? route.abort() : route.continue();
    });
    const secondActor = { ...a, context: second }, secondPage = await page(secondActor);
    await secondPage.getByRole('button', { name: 'Plein', exact: true }).click();
    await shown(secondPage.getByText('Lichtvonk bewaard', { exact: true }).nth(2));
    check(await secondPage.getByText('Lichtvonk bewaard', { exact: true }).count() === 3, 'SUPPLEMENT_SECOND_CONTEXT_RIDDLES_MISSING');
    await shown(secondPage.getByText('Kroonzegel bewaard', { exact: true })); await shown(secondPage.getByText('Lantaarnzegel bewaard', { exact: true })); await shown(secondPage.getByText('Ravenzegel bewaard', { exact: true }));
    await shot(secondPage, 'supplement-games-six-completed', 1440);
    for (const command of questCommands) {
      const response = await second.request.post(`${base}/api/frightnight/command`, { headers: { Origin: base }, data: command });
      check(response.ok(), 'SUPPLEMENT_QUEST_RECEIPT_REPLAY_FAILED');
    }
    const afterReplay = await state(secondActor);
    check(afterReplay.progress.awards.length === complete.progress.awards.length && afterReplay.progress.sparks === complete.progress.sparks, 'SUPPLEMENT_QUEST_REPLAY_DUPLICATE_AWARD');
    pass('KID-02', 'six completed quests survive reload and an independent context; exact command replays add no awards', { quests: 6, independentContexts: 2 });
    const beaconPage = await page(b);
    async function scan(token, start = false) {
      await beaconPage.getByRole('button', { name: start ? 'Scan de start-QR' : 'Scan bij deze bestemming', exact: true }).click();
      await beaconPage.getByLabel('Of voer de code van het bord in', { exact: true }).fill(token);
      await clickCommand(beaconPage, start ? 'journey.start' : 'journey.complete', () => beaconPage.getByRole('button', { name: 'Controleer code', exact: true }).click());
    }
    await scan(await qr(), true);
    let bs = await state(b);
    check(bs.current && bs.current.zone.type !== 'finale', 'SUPPLEMENT_BEACON_ORDINARY_DESTINATION_REQUIRED');
    await scan(await qr(bs.current.zoneId)); bs = await state(b);
    check(bs.progress.visits.length === 1, 'SUPPLEMENT_BEACON_ORDINARY_SCAN_NOT_RECORDED');
    await beaconPage.getByText('Ik wil stoppen of terugkeren', { exact: true }).click();
    await clickCommand(beaconPage, 'journey.finish', () => beaconPage.getByRole('button', { name: 'Naar de Duinpadfinale', exact: true }).click());
    bs = await state(b); check(bs.current?.zone.type === 'finale', 'SUPPLEMENT_BEACON_FINALE_REQUIRED');
    await scan(await qr(bs.current.zoneId)); bs = await state(b);
    check(['finished', 'completed'].includes(bs.journey.state) && bs.quests.every(item => !item.completed), 'SUPPLEMENT_BEACON_INDEPENDENT_FINALE_REQUIRED');
    pass('BAK-02', 'separate zero-quest family completes actual start, ordinary visit and Duinpad final scan');
    await beaconPage.getByRole('button', { name: 'Nachtpas', exact: true }).click();
    for (let step = 1; step <= 3; step++) {
      await beaconPage.getByRole('button', { name: 'Ontdek het proeflicht', exact: true }).click();
      await shown(beaconPage.getByLabel(`Proeflicht, stap ${step} van 3`, { exact: true }));
    }
    const beaconCommand = await clickCommand(beaconPage, 'beacon.complete', () => beaconPage.getByRole('button', { name: 'Geef het Duinlicht terug', exact: true }).click());
    await shown(beaconPage.getByLabel('Jullie Lichtbaken is voltooid', { exact: true }));
    bs = await state(b);
    check(bs.progress.awards.filter(item => item.key === 'beacon').length === 1 && bs.quests.every(item => !item.completed), 'SUPPLEMENT_BEACON_NOT_INDEPENDENT');
    await shot(beaconPage, 'supplement-beacon-independent-final', 390);
    await beaconPage.reload({ waitUntil: 'domcontentloaded' }); await beaconPage.locator('.fn-environment-nav').waitFor(); await beaconPage.getByRole('button', { name: 'Nachtpas', exact: true }).click();
    const completedButton = beaconPage.getByRole('button', { name: 'Duinlicht teruggegeven', exact: true }); await shown(completedButton);
    check(await completedButton.isDisabled(), 'SUPPLEMENT_BEACON_RELOAD_BUTTON_ENABLED');
    const saved = bs.progress.awards.length;
    await app(b, beaconCommand.request.operation, beaconCommand.request.payload, beaconCommand.request.commandId);
    check((await state(b)).progress.awards.length === saved, 'SUPPLEMENT_BEACON_REPLAY_DUPLICATE_AWARD');
    pass('BAK-02', 'all three digital steps and independent beacon completion persist without six quests; reload/replay award once');
    check(pageErrors === 0, 'SUPPLEMENT_GAMES_BROWSER_RUNTIME_ERROR');
    detail.status = 'passed';
  } catch (error) { detail.status = 'failed'; throw error; }
  finally { detail.completedAt = new Date().toISOString(); for (const pg of pages) await pg.close().catch(() => {}); }
}
